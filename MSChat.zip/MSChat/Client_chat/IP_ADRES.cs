﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Client_chat
{
    internal class IP_ADRES
    {
        public static string Ip_adress { get; set; }
    }
}
